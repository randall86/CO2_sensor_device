# CO2_sensor_device
A CO2 sensor medical device utilizing Espressif's ESP32-WROOM-32E
